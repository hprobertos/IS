<?php
   
    $servername="127.0.0.1";
    $username="root";
    $password="";
    $dbname="HBCONCEPT";
    
    $conn=new mysqli($servername,$username,$password,$dbname);
    $connection=mysql_connect($servername,$username,$password) or die
    ("No  se establecio la conexion");

    mysql_select_db("HBCONCEPT");
  
    if ($conn->connect_error)
    {
    	die("La coneccion fallo:".$conn->connect_error);
		 
    }
	else
	{
		$buscar=mysql_query("SELECT * FROM cuentausuario WHERE Correo='".$_POST['correoElectronico']."'");
		if (mysql_num_rows($buscar)>0)
		{
            header("Location: paginaRegistro.php?id=existente");
	    }
	    else
	    {

	    	$sql="INSERT INTO cuentausuario(Nombre_1,Nombre_2,Apellido_paterno,Apellido_materno,Correo,Password_usuario,Fraccionamiento,Colonia,N_casa)
				VALUES( '".$_POST['primerNombre']."',
						'".$_POST['segundoNombre']."',
						'".$_POST['apellidoPaterno']."',
						'".$_POST['apellidoMaterno']."',
						'".$_POST['correoElectronico']."',
						'".$_POST['pwd']."',
						'".$_POST['fracDireccion']."',
						'".$_POST['coloniaDireccion']."',
						'".$_POST['numCasa']."')";
				if ($conn->query($sql)== TRUE){
					
					 header("Location: paginaLogin.php");
					
				}
				else
				{
			        echo "Error: ".$sql."<br>".$conn->error;
				}

	    }
	}
	  //cerrar la conexion


	    $conn->close();
	   	
?>