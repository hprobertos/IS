<!DOCTYPE HTML>
<html>
	<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>HB CONCEPT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content=""/>
        <meta name="keywords" content=""/>
        <meta name="author" content=""/>

        <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">

        <!-- Animate.css -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- Font Awesome Icons -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <!-- Bootstrap  -->
        <link rel="stylesheet" href="css/bootstrap.css">
        <!-- Flexslider  -->
        <link rel="stylesheet" href="css/flexslider.css">
        <!-- Flaticons  -->
        <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
        <!-- Owl Carousel -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/owl.theme.default.min.css">
        <!-- Theme style  -->
        <link rel="stylesheet" href="css/style.css">

        <!-- Modernizr JS -->
        <script src="js/modernizr-2.6.2.min.js"></script>
	</head>
    
	<body>
	<div id="colorlib-page">
		<a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
		<aside id="colorlib-aside" role="complementary" class="border js-fullheight">
			<h1 id="colorlib-logo"><a href="index.html">HB CONCEPT</a></h1>
			<nav id="colorlib-main-menu" role="navigation">
				<ul>
                    <li><a href="nosotros.html">Nosotros</a></li>
                    <li><a href="proyecto.html">Proyecto</a></li>
					<li><a href="servicios.html">Servicios</a></li>
                    <p><a class="btn btn-primary btn-learn" href="php/paginaLogin.php">Iniciar Sesión <i class="fas fa-sign-in-alt"></i></a></p>
				</ul>
			</nav>
            
			<div class="colorlib-footer">
                <p><small>&copy; 2018 Todos los derechos reservados | Proyecto hecho por <a href="#" target="_blank">FCQI</a></small></p>
			</div>

		</aside>

		<div id="colorlib-main">
			<aside id="colorlib-hero" class="js-fullheight">
				<div class="flexslider js-fullheight">
					<ul class="slides">
						<li style="background-image: url(images/img_bg_1.jpg);">
							<div class="overlay"></div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-6 col-md-offset-3 col-md-push-3 col-sm-12 col-xs-12 js-fullheight slider-text">
										<div class="slider-text-inner">
										<div class="desc">
												<h1>Catálogo</h1>
													<h2>Accesa a tu cuenta y adquiere nuestros productos</h2>
													<p><a class="btn btn-primary btn-learn" href="php/paginaLogin.php">Click aquí <i class="fas fa-arrow-right"></i></a></p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
						<li style="background-image: url(images/img_bg_2.jpg);">
							<div class="overlay"></div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-6 col-md-offset-3 col-md-push-3 col-sm-12 col-xs-12 js-fullheight slider-text">
										<div class="slider-text-inner">
										<div class="desc">
												<h1>Contactanos</h1>
													<h2>¿Alguna sugerencia o duda?</h2>
													<p><a class="btn btn-primary btn-learn" href="#">¡Si! <i class="fas fa-arrow-right"></i></a></p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
						<li style="background-image: url(../images/img_bg_3.jpg);">
							<div class="overlay"></div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-6 col-md-offset-3 col-md-push-3 col-sm-12 col-xs-12 js-fullheight slider-text">
										<div class="slider-text-inner">
											<div class="desc">
												<h1>Servicios</h1>
													<h2>Conoce lo que podemos ofrecerte</h2>
													<p><a class="btn btn-primary btn-learn" href="#">De acuerdo <i class="fas fa-arrow-right"></i></a></p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
				  	</ul>
			  	</div>
                
			</aside>

			<div class="colorlib-about">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-6">
							<div class="about-img animate-box" data-animate-effect="fadeInLeft" style="background-image: url(../images/img_quienes_somos.jpg);">
							</div>
						</div>
						<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
							<div class="about-desc">
								<span class="heading-meta">Bienvenido</span>
								<h2 class="colorlib-heading">¿Quienes somos?</h2>
								<p style="text-align: justify">Somos una empresa mexicana constituida a partir del 7 de septiembre de 2017 en la ciudad de Tijuana en el estado de Baja California, trabajamos
                                día a día con el fin de mejorar y lograr una mayor calidad en cada pieza que realizamos.</p>
								<p style="text-align: justify">Como diseñadores entendemos la importancia de los detalles, por ello combinamos el trabajo manual con la tecnología CNC láser para proyectar nuestra inspiración a través de finas maderas extraídas de bosques sustentables, entregando en cada corte y producto nuestro mayor esfuerzo para entregar siempre el mejor resultado.</p>
							</div>
							<div class="row padding">
								<div class="col-md-4 no-gutters animate-box" data-animate-effect="fadeInLeft">
									<a href="#" class="steps active">
										<p class="icon"><span><i class="icon-check"></i></span></p>
										<h3>Somos <br>emprendedores</h3>
									</a>
								</div>
								<div class="col-md-4 no-gutters animate-box" data-animate-effect="fadeInLeft">
									<a href="#" class="steps active">
										<p class="icon"><span><i class="icon-check"></i></span></p>
										<h3>Apasionados</h3>
									</a>
								</div>
								<div class="col-md-4 no-gutters animate-box" data-animate-effect="fadeInLeft">
									<a href="#" class="steps active">
										<p class="icon"><span><i class="icon-check"></i></span></p>
										<h3>Mejoramos <br>Tecnicas</h3>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div id="colorlib-counter" class="colorlib-counters" style="background-image: url(../images/cover_bg_1.jpg);" data-stellar-background-ratio="0.5">
				<div class="overlay"></div>
				<div class="colorlib-narrow-content">
					<div class="row">
					</div>
					<div class="row">
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-skyline"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="1539" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Proyectos</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-engineer"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="4" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Empleados</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="5987" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Eventos</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-worker"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="3999" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Conexiones</span>
						</div>
					</div>
				</div>
			</div>

			<div id="get-in-touch" class="colorlib-bg-color">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
							<h2>¡Contactanos!</h2>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
							<p class="colorlib-lead">Si tienes alguna inquetud o sugerencia, puedes mandarnos un correo</p>
							<p><a href="#" class="btn btn-primary btn-learn">Enviar</a></p>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- Sticky Kit -->
	<script src="js/sticky-kit.min.js"></script>
	<!-- Owl carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	
	<!-- MAIN JS -->
	<script src="js/main.js"></script>

	</body>
</html>