USE HBCONCEPT;

select * from cuentausuario;
select * from libreta;

INSERT INTO cuentausuario values(02, 'Aldo', 'Enrique', 'Gallegos', 'Morales', 'Aldo@gmail.com', 12345678, 'Playas', 'Pacifico', 09, 1234567891, 'Tom');
INSERT INTO cuentausuario values(01, 'Leslie', null, 'Gutierrez', 'Barajas', 'Leslie@gmail.com', 12345678, 'Bugambilias', 'Arcos', 12, 1234567891, 'Aldo');

INSERT INTO libreta values(01,'Nogal','Cuadriculada','Azul');

set @usuario="Leslie@gmail.com";
set @contra="12345678";
SELECT * FROM cuentausuario where Correo=@usuario AND Password_usuario =@contra;

set @usuario="Aldo@gmail.com";
set @contra="12345678";
SELECT * FROM cuentausuario where Correo=@usuario AND Password_usuario =@contra;