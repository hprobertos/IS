<?php
	$servername="-";
	$username="-";
	$password="-";
	$dbname="HBCONCEPT"; 

	//Se crea una conexion
	$conn=new mysqli($servername,$username,$password,$dbname);

	//Se revisa la conexion
	if($conn->connect_error){
		die("La conexion fallo: ".$conn->connect_error);
	}else{        
        $sql="INSERT INTO -(pregRecuperacion,Correo)
				VALUES( '".$_POST['preguntaRecuperacion']."',
						'".$_POST['correoElectronico']."')";

		if($conn->query($sql)===TRUE){
			echo '<script>alert("Se ha registrado al nuevo cliente, de manera exitosa")</script>';
		}else{
			header("Location:../php/paginaLogin.php");
			echo '<script>alert("No se ha registrado")</script>';
		}
	}
	//cerrar la conexion
	$conn->close();
	header("Location: paginaPwd.php");
?>