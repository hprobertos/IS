<?php
    $servername="127.0.0.1";
    $username="root";
    $password="";
    $dbname="HBCONCEPT";
    
    $conn=new mysqli($servername,$username,$password,$dbname);
    $connection=mysql_connect($servername,$username,$password) or die
    ("No  se establecio la conexion");

    mysql_select_db("HBCONCEPT");
  
    if ($conn->connect_error)
    {
    	die("La coneccion fallo:".$conn->connect_error);
		 
    }
	else
	{
	    $sql="INSERT INTO presupuesto(NombreCompleto,Correo,Telefono,Material,Estilo,Color,Cantidad)
			VALUES( '".$_POST['txtNC']."',
					'".$_POST['txtCE']."',
					'".$_POST['txtTC']."',
					'".$_POST['opcMaterial']."',
					'".$_POST['opcEstilo']."',
					'".$_POST['opcColor']."',
					'".$_POST['opcCantidad']."')";
			if ($conn->query($sql)== TRUE)
			{
				header("Location: SolicitarPresupuesto.php");	
			}
			else
			{
				echo "Error: ".$sql."<br>".$conn->error;
			}
	}
	  //cerrar la conexion
	    $conn->close();  	
?>